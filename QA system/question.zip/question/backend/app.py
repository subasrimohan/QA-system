from flask import Flask, request, jsonify, render_template
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Extended Q&A database
qa_pairs = {
    "what are your working hours": "Our working hours are 9 AM to 6 PM, Monday to Friday.",
    "how can i reset my password": "Click on 'Forgot Password' on the login page and follow the instructions.",
    "what is your return policy": "You can return products within 30 days with a receipt.",
    "do you offer support": "Yes, we offer 24/7 customer support via phone and chat.",
    "where is my order": "You can track your order status under 'My Orders' section after login.",
    "how can i contact support": "You can contact support via email at support@example.com or call 123-456-7890.",
    "how do i cancel my order": "To cancel an order, go to 'My Orders' and click 'Cancel' next to the item.",
    "what payment methods do you accept": "We accept credit/debit cards, net banking, and digital wallets.",
    "is cash on delivery available": "Yes, cash on delivery is available for select regions.",
    "can i change my delivery address": "Yes, you can change your delivery address before the order is shipped.",
    "do you have a mobile app": "Yes, our mobile app is available on both Android and iOS platforms.",
    "how long does delivery take": "Standard delivery takes 3–5 business days depending on your location.",
    "are there any shipping charges": "Shipping is free for orders above $50. Otherwise, a $5 fee applies.",
    "how do i apply a coupon code": "You can enter your coupon code during checkout in the 'Apply Coupon' section.",
    "what if i received a damaged product": "If you received a damaged item, contact our support within 7 days for a free replacement."
}

def get_answer(user_question):
    question = user_question.lower().strip()
    for key in qa_pairs:
        if key in question:
            return qa_pairs[key]
    return "Sorry, I couldn't understand your question. Please try rephrasing it."

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/ask', methods=['POST'])
def ask():
    data = request.json
    question = data.get('question', '')
    answer = get_answer(question)
    return jsonify({'answer': answer})

if __name__ == '__main__':
    app.run(debug=True)
